/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package aula1;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import jdk.nashorn.internal.objects.NativeDebug;

/**
 *
 * @author danilo
 */
public class Aula1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JFrame janela = new JFrame ("Projeto Disciplina!");
        JPanel painel = new JPanel();
        janela.setSize(300,200);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);
        janela.add(painel);
       /* JLabel rotulo = new JLabel();
        rotulo.setText("oii");
        janela.add(rotulo);*/
        String number = JOptionPane.showInputDialog("Digite um numero");
        JOptionPane.showMessageDialog(null,"O número digitado foi: "+number);
        
    }
    
}




